const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Connect to MongoDB
mongoose.connect('mongodb+srv://assignment2:8MeOquaMgMd9Vc6E@cluster0.s7tua.mongodb.net/portfolioDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('Connected to MongoDB');
}).catch(err => console.log(err));

// Define the Item schema
const itemSchema = new mongoose.Schema({
    item: String,
    price: Number,
    quantity: Number,
    date: Date
});

// Create the Item model
const Item = mongoose.model('Item', itemSchema);

// Define the User schema
const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    phone: String
});

// Create the User model
const User = mongoose.model('User', userSchema);

// Define the Contact schema
const contactSchema = new mongoose.Schema({
    name: String,
    email: String,
    phone: String
});

// Create the Contact model
const Contact = mongoose.model('Contact', contactSchema);

// Basic route
app.get('/', (req, res) => {
    res.send('Hello, MongoDB is connected!');
});

// Route for Items
app.post('/items', async (req, res) => {
    const newItem = new Item(req.body);
    try {
        await newItem.save();
        res.status(201).send(newItem);
    } catch (error) {
        res.status(400).send(error);
    }
});

app.get('/items', async (req, res) => {
    try {
        const items = await Item.find();
        res.json(items);
    } catch (error) {
        res.status(500).send('Error retrieving items: ' + error.message);
    }
});

// Contacts Routes
app.get('/api/contacts', async (req, res) => {
    try {
        const contacts = await Contact.find();
        res.json(contacts);
    } catch (error) {
        res.status(500).send('Error retrieving contacts: ' + error.message);
    }
});

app.get('/api/contacts/:id', async (req, res) => {
    try {
        const contact = await Contact.findById(req.params.id);
        if (!contact) return res.status(404).send('Contact not found');
        res.json(contact);
    } catch (error) {
        res.status(500).send('Error retrieving contact: ' + error.message);
    }
});

app.post('/api/contacts', async (req, res) => {
    const newContact = new Contact(req.body);
    try {
        await newContact.save();
        res.status(201).json(newContact);
    } catch (error) {
        res.status(400).send('Error creating contact: ' + error.message);
    }
});

app.put('/api/contacts/:id', async (req, res) => {
    try {
        const contact = await Contact.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!contact) return res.status(404).send('Contact not found');
        res.json(contact);
    } catch (error) {
        res.status(400).send('Error updating contact: ' + error.message);
    }
});

app.delete('/api/contacts/:id', async (req, res) => {
    try {
        const contact = await Contact.findByIdAndDelete(req.params.id);
        if (!contact) return res.status(404).send('Contact not found');
        res.status(204).send(); // No content
    } catch (error) {
        res.status(500).send('Error deleting contact: ' + error.message);
    }
});

app.delete('/api/contacts', async (req, res) => {
    try {
        await Contact.deleteMany();
        res.status(204).send(); // No content
    } catch (error) {
        res.status(500).send('Error deleting contacts: ' + error.message);
    }
});

// Users Routes
app.get('/api/users', async (req, res) => {
    try {
        const users = await User.find();
        res.json(users);
    } catch (error) {
        res.status(500).send('Error retrieving users: ' + error.message);
    }
});

app.get('/api/users/:id', async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) return res.status(404).send('User not found');
        res.json(user);
    } catch (error) {
        res.status(500).send('Error retrieving user: ' + error.message);
    }
});

app.post('/api/users', async (req, res) => {
    const newUser = new User(req.body);
    try {
        await newUser.save();
        res.status(201).json(newUser);
    } catch (error) {
        res.status(400).send('Error creating user: ' + error.message);
    }
});

app.put('/api/users/:id', async (req, res) => {
    try {
        const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!user) return res.status(404).send('User not found');
        res.json(user);
    } catch (error) {
        res.status(400).send('Error updating user: ' + error.message);
    }
});

app.delete('/api/users/:id', async (req, res) => {
    try {
        const user = await User.findByIdAndDelete(req.params.id);
        if (!user) return res.status(404).send('User not found');
        res.status(204).send(); // No content
    } catch (error) {
        res.status(500).send('Error deleting user: ' + error.message);
    }
});

app.delete('/api/users', async (req, res) => {
    try {
        await User.deleteMany();
        res.status(204).send(); // No content
    } catch (error) {
        res.status(500).send('Error deleting users: ' + error.message);
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
